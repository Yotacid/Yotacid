<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div>
<h1>Fuck u mahn</h1> <br />
<h2>Wrong password b0ss</h2>
<a href="index.php"><img src="new.jpg" /></a>
<audio autoplay>
	<source src="sound/distorted.mp3" type="audio/mpeg">
</audio>
</div>
<style type="text/css">
	div{
		text-align: center;
		width: 70%;
		margin:0 auto;
	}
	h1{
		margin-bottom: -20px;
		color: purple;
	}
	h2{
		margin-bottom: 1px;
		color: purple;
	}
</style>
</body>
</html